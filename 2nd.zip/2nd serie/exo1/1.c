#include <stdio.h>
#include <stdlib.h>

typedef struct time
{
    int hour ;
    int minuts ;
    int seconds  ;
}time;
void timepr(struct time *first)
{
    printf("the current time is -------------> %d h-%d min-%d sec\n",first->hour,first->minuts,first->seconds);

}
void addh(struct time *first , int size)
{
    if (size > 0) 
    {
        first->hour += size;
        while (first->hour >= 24) 
        {
            first->hour -= 24;
        }
    }
}
void addMinutes(struct time *t, int minutesToAdd) 
{
    t->minuts += minutesToAdd;

    while (t->minuts >= 60) 
    {
        t->hour++;
        t->minuts -= 60;
    }
}

void addSeconds(struct time *t, int secondsToAdd) 
{
    t->seconds += secondsToAdd;

    while (t->seconds >= 60) 
    {
        t->minuts++;
        t->seconds -= 60;
    }

    while (t->minuts >= 60) 
    {
        t->hour++;
        t->minuts -= 60;
    }
}
int main(void)
{
    time t1 = {0,0,0};
    printf("here is the original time\n");
    printf("%d h-%d min-%d sec\n",t1.hour,t1.minuts,t1.seconds);
    printf("if you wante to change it type 1 else type 0\n");
    int n,b,g,t;
    scanf("%d",&n);
    printf("enter the number of seconds plz\n");
    scanf("%d",&b);
    printf("enter the number of minuts plz\n");
    scanf("%d",&g);
    printf("enter the number of hours plz\n");
    scanf("%d",&t);
    if (n ==1)
    {
        addh(&t1,t);
        addMinutes(&t1,g);
        addSeconds(&t1, b);
        timepr(&t1);

    }
}