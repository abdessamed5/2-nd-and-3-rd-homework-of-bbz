
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_BOOKS 1000
#define MAX_TITLE_LENGTH 100

typedef struct 
{
    char title[MAX_TITLE_LENGTH];
    int quantity;
} Book;

typedef struct 
{
    Book books[MAX_BOOKS];
    int num_books;
} Library;

void initLibrary(Library *library) 
{
    library->num_books = 0;
}

void addBook(Library *library, const char *title) 
{
    int i;
    for (i = 0; i < library->num_books; i++) {
        if (strcmp(library->books[i].title, title) == 0) 
        {
            library->books[i].quantity++;
            return;
        }
    }
    if (library->num_books < MAX_BOOKS) {
        strcpy(library->books[library->num_books].title, title);
        library->books[library->num_books].quantity = 1;
        library->num_books++;
    } else {
        printf("Library is full, cannot add more books.\n");
    }
}

void retrieveBook(Library *library, const char *title) 
{
    int i;
    for (i = 0; i < library->num_books; i++) 
    {
        if (strcmp(library->books[i].title, title) == 0) 
        {
            library->books[i].quantity--;
            if (library->books[i].quantity == 0) 
            {
                library->num_books--;
                library->books[i] = library->books[library->num_books];
            }
            return;
        }
    }
    printf("Book '%s' not found in the library.\n", title);
}

void printLibrary(Library *library) {
    printf("Library contents:\n");
    for (int i = 0; i < library->num_books; i++) {
        printf("%s: %d\n", library->books[i].title, library->books[i].quantity);
    }
}

int main(void) 
{
    Library library;
    initLibrary(&library);

    addBook(&library, "Book1");
    addBook(&library, "Book2");
    addBook(&library, "Book3");
    addBook(&library, "Book4");

    printLibrary(&library);

    retrieveBook(&library, "Book1");
    retrieveBook(&library, "Book2");
    retrieveBook(&library, "Book4");

    printLibrary(&library);
}
