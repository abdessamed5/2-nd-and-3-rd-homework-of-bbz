#include <stdio.h>

void crb( char *inputFileName,  char *outputFileName) 
{
    FILE *inputFile, *outputFile;
    int number, sum, count;
    float average;

    inputFile = fopen(inputFileName, "r");
    if (inputFile == NULL) 
    {
        printf("Error opening input file.\n");
        return;
    }

    outputFile = fopen(outputFileName, "w");
    if (outputFile == NULL) 
    {
        printf("Error opening output file.\n");
        fclose(inputFile);
        return;
    }

    while (fscanf(inputFile, "%d", &number) != EOF) 
    {
        sum = number;
        count = 1;

        while (fscanf(inputFile, "%d", &number) != EOF && number != 0) 
        {
            sum += number;
            count++;
        }

        if (count > 0) 
        {
            average = (float)sum / count;
            fprintf(outputFile, "%.2f\n", average);
        }
    }
    fclose(inputFile);
    fclose(outputFile);
}

int main(void) 
{
    char *input = "F.txt";
    char *output = "G.txt";
    crb(input, output);
    printf("Average file created successfully.\n");

}
