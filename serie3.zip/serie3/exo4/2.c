#include <stdio.h>

void rm( char *inputFileName,  char *outputFileName) 
{
    FILE *inputFile, *outputFile;
    float number;

    inputFile = fopen(inputFileName, "r");
    if (inputFile == NULL) 
    {
        printf("error opening input file.\n");
        return;
    }

    outputFile = fopen(outputFileName, "w");
    if (outputFile == NULL)
    {
        printf("error opening output file.\n");
        fclose(inputFile);
        return;
    }

    while (fscanf(inputFile, "%f", &number) != EOF) 
    {
        if (number != 0) 
        {
            fprintf(outputFile, "%.2f\n", number);
        }
    }
    fclose(inputFile);
    fclose(outputFile);
}

int main(void)
{
     char *inpute = "G.txt";
     char *output = "G_no_zeros.txt";
    rm(inpute, output);
    printf("Zero values removed successfully.\n");
}

