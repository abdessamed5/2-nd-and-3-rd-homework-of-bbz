
#include <stdio.h>

#define MAX_NAME_LENGTH 20
#define MAX_WISH_LENGTH 6

typedef struct 
{
    int ID;
    char lastName[MAX_NAME_LENGTH + 1];
    char firstName[MAX_NAME_LENGTH + 1];
    float average;
    char wish[MAX_WISH_LENGTH + 1];
} Student;

void ad( char *inputFileName,  char *outputFileName) 
{
    FILE *inputFile, *outputFile;
    Student student;
    inputFile = fopen(inputFileName, "rb");
    if (inputFile == NULL) 
    {
        printf("Error opening input file.\n");
        return;
    }
    outputFile = fopen(outputFileName, "wb");
    if (outputFile == NULL) 
    {
        printf("Error creating output file.\n");
        fclose(inputFile);
        return;
    }
    while (fread(&student, sizeof(Student), 1, inputFile) == 1) 
    {
        if (student.average >= 10.0) 
        {
            fwrite(&student, sizeof(Student), 1, outputFile);
        }
    }
    fclose(inputFile);
    fclose(outputFile);
}

int main(void) 
{
    char *input = "FSTD.bin";
    char *output = "Fadmis.bin";
    ad(input, output);
    printf("Fadmis file created successfully.\n");

}
