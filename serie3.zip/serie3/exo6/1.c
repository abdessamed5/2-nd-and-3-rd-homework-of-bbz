#include <stdio.h>

#define MAX_NAME_LENGTH 20
#define MAX_WISH_LENGTH 6

typedef struct 
{
    int ID;
    char lastName[MAX_NAME_LENGTH + 1];
    char firstName[MAX_NAME_LENGTH + 1];
    float average;
    char wish[MAX_WISH_LENGTH + 1];
} Student;

int main(void) 
{
    Student student1 = {1, "Doe", "nigger", 85.855, "Computer"};
    printf("Student ID: %d\n", student1.ID);
    printf("Last Name: %s\n", student1.lastName);
    printf("First Name: %s\n", student1.firstName);
    printf("Average: %.2f\n", student1.average);
    printf("Wish: %s\n", student1.wish);

}

