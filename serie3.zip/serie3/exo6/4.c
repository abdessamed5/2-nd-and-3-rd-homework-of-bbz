#include <stdio.h>
#include <string.h>

#define MAX_WISH_LENGTH 6

typedef struct
{
    char wish[MAX_WISH_LENGTH + 1];
    float average;
} WishInfo;

void Max(char *inputFileName) 
{
    FILE *inputFile;
    WishInfo maxWish;
    maxWish.average = -1; 

    inputFile = fopen(inputFileName, "r");

    if (inputFile == NULL) 
    {
        printf("Error opening input file.\n");
        return;
    }

    WishInfo currentWish;

    while (fscanf(inputFile, "Wish: %s, Number of Students: %*d, Average: %f", currentWish.wish, &currentWish.average) == 2)
    {
        if (currentWish.average > maxWish.average) 
        {
            strcpy(maxWish.wish, currentWish.wish);
            maxWish.average = currentWish.average;
        }
    }

    fclose(inputFile);

    printf("Wish with the highest average: %s, Average: %.2f\n", maxWish.wish, maxWish.average);
}

int main(void) 
{
    char *input = "FWish.txt";
    Max(input);
}
