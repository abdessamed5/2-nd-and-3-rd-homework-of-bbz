#include <stdio.h>
#include <string.h>

#define MAX_WISH_LENGTH 6

typedef struct 
{
    int ID;
    char lastName[MAX_WISH_LENGTH + 1];
    char firstName[MAX_WISH_LENGTH + 1];
    float average;
    char wish[MAX_WISH_LENGTH + 1];
} Student;

typedef struct 
{
    char wish[MAX_WISH_LENGTH + 1];
    int count;
    float totalAverage;
} WishInfo;

void ch( char *inputFileName,  char *outputFileName) 
{
    FILE *inputFile, *outputFile;
    Student student;
    inputFile = fopen(inputFileName, "rb");
    if (inputFile == NULL) {
        printf("Error opening input file.\n");
        return;
    }

    WishInfo wishes[MAX_WISH_LENGTH];
    int i;

    for (i = 0; i < MAX_WISH_LENGTH; i++) 
    {
        strcpy(wishes[i].wish, ""); 
        wishes[i].count = 0;
        wishes[i].totalAverage = 0.0;
    }

    while (fread(&student, sizeof(Student), 1, inputFile) == 1) 
    {
        int wishIndex = -1;
        for (i = 0; i < MAX_WISH_LENGTH; i++) 
        {
            if (strcmp(student.wish, wishes[i].wish) == 0) 
            {
                wishIndex = i;
                break;
            }
        }

        if (wishIndex == -1) 
        {
            for (i = 0; i < MAX_WISH_LENGTH; i++) 
            {
                if (strcmp(wishes[i].wish, "") == 0) 
                {
                    strcpy(wishes[i].wish, student.wish);
                    wishIndex = i;
                    break;
                }
            }
        }

        if (wishIndex != -1) 
        {
            wishes[wishIndex].count++;
            wishes[wishIndex].totalAverage += student.average;
        }
    }

    fclose(inputFile);
    for (i = 0; i < MAX_WISH_LENGTH; i++) 
    {
        if (wishes[i].count > 0) 
        {
            wishes[i].totalAverage /= wishes[i].count;
        }
    }
    outputFile = fopen(outputFileName, "w");
    if (outputFile == NULL) 
    {
        printf("Error creating output file.\n");
        return;
    }
    for (i = 0; i < MAX_WISH_LENGTH; i++) 
    {
        if (strcmp(wishes[i].wish, "") != 0)
        {
            fprintf(outputFile, "Wish: %s, Number of Students: %d, Average: %.2f\n", wishes[i].wish, wishes[i].count, wishes[i].totalAverage);
        }
    }
    fclose(outputFile);
}

int main(void) 
{
    char *input = "Fadmis.bin";
    char *output = "FWish.txt";
    ch(input, output);
    printf("FWish file created successfully.\n");
}
