#include <stdio.h>

void in( char *fileName, int N) 
{
    FILE *file;
    int currentNumber;
    int flag = 0;

    file = fopen(fileName, "r+");

    if (file == NULL) 
    {
        printf("error opening file.\n");
        return;
    }

    while (fscanf(file, "%d", &currentNumber) != EOF) 
    {
        if (currentNumber > N) 
        {
            fseek(file, -sizeof(int), SEEK_CUR);
            
            fwrite(&N, sizeof(int), 1, file);
            
            fseek(file, 0, SEEK_END);
            
            flag = 1;
            
            break;
        }
    }

    if (!flag) 
    {
        fwrite(&N, sizeof(int), 1, file);
    }

    fclose(file);
}

int main(void) 
{
    char *file = "FData.txt";
    in(file, 5);
    printf("Integer inserted successfully.\n");
}
