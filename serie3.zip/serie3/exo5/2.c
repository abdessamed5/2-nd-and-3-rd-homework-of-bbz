#include <stdio.h>
#include <stdlib.h>

void in( char *fileName, int N) 
{
    FILE *file;
    int currentNumber;
    int flag = 0;

    file = fopen(fileName, "r+");

    if (file == NULL) 
    {
        printf("error opening file.\n");
        return;
    }

    while (fscanf(file, "%d", &currentNumber) != EOF) 
    {
        if (currentNumber > N) 
        {
            fseek(file, -sizeof(int), SEEK_CUR);
            
            fwrite(&N, sizeof(int), 1, file);
            
            fseek(file, 0, SEEK_END);
            
            flag = 1;
            
            break;
        }
    }

    if (!flag)
    {
        fwrite(&N, sizeof(int), 1, file);
    }

    fclose(file);
}

void sor(const char *fileName) 
{
    FILE *file, *tempFile;
    int number;

    file = fopen(fileName, "r");
    if (file == NULL) 
    {
        printf("error opening file.\n");
        return;
    }

    tempFile = fopen("FTemp.txt", "w");
    if (tempFile == NULL) 
    {
        printf("error creating temporary file.\n");
        fclose(file);
        return;
    }

    while (fscanf(file, "%d", &number) != EOF) 
    {
        in("FTemp.txt", number);
    }

    fclose(file);
    fclose(tempFile);

    remove(fileName);
    rename("FTemp.txt", fileName);

    printf("File sorted successfully.\n");
}

int main(void)
{
     char *file = "FData.txt";
    sor(file);
}

