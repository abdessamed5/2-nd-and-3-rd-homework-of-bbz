#include <stdio.h>
#include <string.h>

#define MAX_WORDS 1000 

typedef struct 
{
    char word[100]; 
    int count;
} WordCount;

void crt( char *inputFileName,  char *outputFileName) 
{
    FILE *inputFile, *outputFile;
    char word[100];
    WordCount wordCounts[MAX_WORDS];
    int numWords = 0;
    int i, j, found;

    inputFile = fopen(inputFileName, "r");
    if (inputFile == NULL) 
    {
        printf("error opening input fil\n");
        return;
    }

    outputFile = fopen(outputFileName, "w");
    if (outputFile == NULL)
    {
        printf("error opening output fil\n");
        fclose(inputFile);
        return;
    }

    while (fscanf(inputFile, "%s", word) != EOF) 
    {
        found = 0;
        for (i = 0; i < numWords; i++) 
        {
            if (strcmp(word, wordCounts[i].word) == 0) 
            {
                wordCounts[i].count++;
                found = 1;
                break;
            }
        }
        if (!found) 
        {
            strcpy(wordCounts[numWords].word, word);
            wordCounts[numWords].count = 1;
            numWords++;
        }
    }

    for (i = 0; i < numWords; i++) 
    {
        fprintf(outputFile, "%s %d\n", wordCounts[i].word, wordCounts[i].count);
    }

    fclose(inputFile);
    fclose(outputFile);
}

int main(void) 
{
     char *input = "FWord.txt";
     char *output = "FSTAT.txt";
    crt(input, output);
    printf("Word statistics file created successfully\n");
}

