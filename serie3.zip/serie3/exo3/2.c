
#include <stdio.h>
#include <string.h>

void crt(char C, char *inputFileName, char *outputFileName) 
{
    FILE *inputFile, *outputFile;
    char word[100];

    inputFile = fopen(inputFileName, "r");
    if (inputFile == NULL) {
        printf("Error opening input file\n");
        return;
    }

    outputFile = fopen(outputFileName, "w");
    if (outputFile == NULL) 
    {
        printf("Error opening output fil\n");
        fclose(inputFile);
        return;
    }

    while (fscanf(inputFile, "%s", word) != EOF) 
    {
        if (word[0] == C) 
        {
            fprintf(outputFile, "%s\n", word);
        }
    }
    fclose(inputFile);
    fclose(outputFile);
}

int main(void) 
{
    char *input = "FWord.txt";
    char *outpout = "FPR.txt";
    char c = 'C';

    crt(c, input, outpout);
    printf("Filtered word file created successfully.\n");

}
