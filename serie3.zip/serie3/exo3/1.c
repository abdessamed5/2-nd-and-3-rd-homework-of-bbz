#include <stdio.h>

void crt( char *inputFileName,  char *outputFileName) 
{
    FILE *inputFile, *outputFile;
    char ch, prevCh = ' ';

    
    inputFile = fopen(inputFileName, "r");
    if (inputFile == NULL) 
    {
        printf("Error opening input file\n");
        return;
    }

    outputFile = fopen(outputFileName, "w");
    if (outputFile == NULL) 
    {
        printf("Error opening output fil\n");
        fclose(inputFile);
        return;
    }

    while ((ch = fgetc(inputFile)) != EOF) 
    {
        if (ch != ' ') 
        {
            fputc(ch, outputFile);
        } else if (prevCh != ' ') 
        {
            fputc('\n', outputFile);
        }
        prevCh = ch;
    }
    fclose(inputFile);
    fclose(outputFile);
}

int main(void) 
{
    
    char *input = "FCAR.txt";
    char *outpout = "FWord.txt";

    crt(input, outpout);
    printf("file created successfully\n");
}

