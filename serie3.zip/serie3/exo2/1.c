#include <stdio.h>
#include <string.h>

#define MAX_STUDENTS 100
#define MAX_NAME_LENGTH 20

typedef struct 
{
    int Id;
    char FName[MAX_NAME_LENGTH + 1];
    char LName[MAX_NAME_LENGTH + 1];
    float average;
} Student;

void cpy(Student T[], int size) 
{
    FILE *fp;
    int i;

    fp = fopen("ADMIS", "wb");

    if (fp == NULL) 
    {
        printf("Error opening file.\n");
        return;
    }

    
    for (i = 0; i < size; i++) 
    {
        
        if (T[i].average >= 10) 
        {
            fwrite(&T[i], sizeof(Student), 1, fp);
        }
    }

    fclose(fp);
}

int main(void) 
{
    Student T[MAX_STUDENTS] = {{1, "John", "nn", 9.5},{2, "Jane", "mi", 10.5}};
    int num_students = 2; 
    cpy(T, num_students);
    return 0;
}
