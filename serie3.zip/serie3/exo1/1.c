#include <stdio.h>

int main(void) 
{
    FILE *fp;
    int number;
    int sum = 0;
    int count = 0;
    double average;

    fp = fopen("NOMBRES.BIN", "rb");

    if (fp == NULL) {
        printf("Error opening file.\n");
        return 1;
    }

    while (fread(&number, sizeof(int), 1, fp) == 1) 
    {
        printf("%d\n", number);
        sum += number;
        count++;
    }

    fclose(fp);

    // average
    if (count > 0) 
    {
        average = (double)sum / count;
        printf("Sum: %d\n", sum);
        printf("Average: %.2f\n", average);
    } 
    else 
    {
        printf("No numbers found in the file\n");
    }
}
